# TaskFlow — Fullstack Kanban Board

A portfolio-ready task management app built with **Next.js 14** (App Router).
Demonstrates fullstack skills: REST API, file persistence, CRUD, and a polished UI.

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## ✨ Features

- **3-column Kanban board** — Todo, In Progress, Done
- **Add tasks** — title, description, priority, due date
- **Move tasks** — forward/backward across columns with PATCH API calls
- **Delete tasks** — with confirmation prompt
- **Overdue detection** — highlights past-due tasks in red
- **Priority filter** — filter by High / Medium / Low
- **Progress bar** — live completion percentage in the header
- **Responsive layout** — single-column on mobile
- **Seed data** — pre-loaded tasks on first run

---

## 🗂 Project Structure

```
taskflow/
├── app/
│   ├── layout.js            # Root layout + Google Fonts
│   ├── page.js              # Kanban board UI (Client Component)
│   ├── globals.css          # CSS variables + global styles
│   └── api/
│       └── tasks/
│           ├── route.js         # GET all, POST new
│           └── [id]/
│               └── route.js     # PATCH update, DELETE
├── components/
│   ├── TaskCard.js          # Individual task card + actions
│   └── AddTaskModal.js      # Modal form for new tasks
├── lib/
│   └── db.js                # File-based JSON "database"
└── data/
    └── tasks.json           # Auto-created on first run
```

---

## 🔌 API Reference

| Method | Endpoint           | Description         |
|--------|--------------------|---------------------|
| GET    | `/api/tasks`       | Get all tasks       |
| POST   | `/api/tasks`       | Create a new task   |
| PATCH  | `/api/tasks/:id`   | Update a task       |
| DELETE | `/api/tasks/:id`   | Delete a task       |

### POST body
```json
{
  "title": "My task",
  "description": "Optional details",
  "priority": "high | medium | low",
  "dueDate": "2026-05-20"
}
```

### PATCH body (any field is optional)
```json
{
  "status": "todo | in-progress | done",
  "title": "Updated title",
  "priority": "low"
}
```

---

## 🛠 Tech Stack

| Layer     | Tech                      |
|-----------|---------------------------|
| Framework | Next.js 14 (App Router)   |
| Styling   | CSS-in-JS (inline styles) |
| Storage   | JSON file via `fs` module |
| IDs       | `uuid` v4                 |
| Fonts     | Inter + JetBrains Mono    |

---

## 💡 What This Demonstrates

This project is designed to show off junior fullstack skills:

1. **Next.js App Router** — `app/` directory, layouts, Client Components (`'use client'`)
2. **REST API routes** — proper HTTP methods (GET, POST, PATCH, DELETE), status codes, error handling
3. **Server-side persistence** — reading/writing JSON with Node.js `fs` module
4. **State management** — `useState`, `useEffect`, optimistic UI updates
5. **Component design** — reusable, prop-driven components
6. **Error handling** — try/catch on every API call, user-facing error messages
7. **Responsive design** — CSS grid, mobile-friendly layout

---

## 🔮 Ideas to Extend

Ready to level up? Try adding:

- [ ] **Drag-and-drop** — use `@hello-pangea/dnd` library
- [ ] **Authentication** — NextAuth.js with GitHub login
- [ ] **Real database** — swap `lib/db.js` for Prisma + PostgreSQL
- [ ] **Search** — filter tasks by title keyword
- [ ] **Edit tasks** — inline editing of title/description
- [ ] **Tags** — color-coded category labels
- [ ] **Dark/Light toggle** — CSS variable theme switching

---

## 📦 Deploy to Vercel

> **Note:** The file-based database won't persist on Vercel's serverless environment. Before deploying, swap `lib/db.js` for a real database (Supabase, PlanetScale, etc.) or use Vercel KV.

```bash
npm run build   # Check for errors
```

Then connect your GitHub repo to [vercel.com](https://vercel.com) for one-click deploys.
