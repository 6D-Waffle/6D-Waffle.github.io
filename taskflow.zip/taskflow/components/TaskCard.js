'use client'
import { useState } from 'react'

const PRIORITY_COLORS = {
  high:   { bg: 'rgba(248,113,113,0.12)', text: '#f87171', dot: '#f87171' },
  medium: { bg: 'rgba(251,191,36,0.12)',  text: '#fbbf24', dot: '#fbbf24' },
  low:    { bg: 'rgba(52,211,153,0.12)',  text: '#34d399', dot: '#34d399' },
}

const STATUS_FLOW = {
  'todo':        { next: 'in-progress', nextLabel: 'Start →',   prev: null,         prevLabel: null },
  'in-progress': { next: 'done',        nextLabel: 'Complete ✓', prev: 'todo',       prevLabel: '← Back' },
  'done':        { next: null,          nextLabel: null,         prev: 'in-progress', prevLabel: '← Undo' },
}

function formatDate(dateStr) {
  if (!dateStr) return null
  const d = new Date(dateStr + 'T00:00:00')
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function isOverdue(dateStr) {
  if (!dateStr) return false
  return new Date(dateStr + 'T00:00:00') < new Date()
}

export default function TaskCard({ task, onUpdate, onDelete }) {
  const [loading, setLoading] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const flow = STATUS_FLOW[task.status]
  const priority = PRIORITY_COLORS[task.priority] || PRIORITY_COLORS.medium
  const overdue = isOverdue(task.dueDate) && task.status !== 'done'

  async function moveTask(newStatus) {
    setLoading(true)
    try {
      const res = await fetch(`/api/tasks/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })
      if (!res.ok) throw new Error()
      const updated = await res.json()
      onUpdate(updated)
    } catch {
      alert('Failed to update task.')
    } finally {
      setLoading(false)
    }
  }

  async function deleteTask() {
    if (!confirm('Delete this task?')) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/tasks/${task.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error()
      onDelete(task.id)
    } catch {
      alert('Failed to delete task.')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="fade-up" style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '16px',
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      opacity: deleting ? 0.5 : 1,
      transition: 'opacity 0.2s, transform 0.2s, box-shadow 0.2s',
      cursor: 'default',
    }}
    onMouseEnter={e => {
      e.currentTarget.style.transform = 'translateY(-2px)'
      e.currentTarget.style.boxShadow = '0 8px 24px rgba(0,0,0,0.3)'
      e.currentTarget.style.borderColor = 'var(--surface2)'
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform = 'translateY(0)'
      e.currentTarget.style.boxShadow = 'none'
      e.currentTarget.style.borderColor = 'var(--border)'
    }}
    >
      {/* Header row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
        <span style={{
          fontSize: '11px', fontWeight: 600, letterSpacing: '0.06em',
          textTransform: 'uppercase', padding: '3px 8px',
          background: priority.bg, color: priority.text,
          borderRadius: '4px', whiteSpace: 'nowrap',
        }}>
          <span style={{ marginRight: '5px' }}>●</span>{task.priority}
        </span>
        <button
          onClick={deleteTask}
          disabled={deleting}
          title="Delete task"
          style={{
            background: 'none', border: 'none',
            color: 'var(--muted)', fontSize: '16px', lineHeight: 1,
            padding: '2px 6px', borderRadius: '4px',
            transition: 'color 0.2s, background 0.2s',
          }}
          onMouseEnter={e => { e.currentTarget.style.color = 'var(--red)'; e.currentTarget.style.background = 'rgba(248,113,113,0.1)' }}
          onMouseLeave={e => { e.currentTarget.style.color = 'var(--muted)'; e.currentTarget.style.background = 'none' }}
        >
          ×
        </button>
      </div>

      {/* Title */}
      <h3 style={{
        fontSize: '14px', fontWeight: 600, lineHeight: 1.4,
        textDecoration: task.status === 'done' ? 'line-through' : 'none',
        color: task.status === 'done' ? 'var(--muted)' : 'var(--text)',
      }}>
        {task.title}
      </h3>

      {/* Description */}
      {task.description && (
        <p style={{ fontSize: '13px', color: 'var(--muted)', lineHeight: 1.6 }}>
          {task.description}
        </p>
      )}

      {/* Due date */}
      {task.dueDate && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '5px',
          fontSize: '12px', color: overdue ? 'var(--red)' : 'var(--muted)',
          fontFamily: 'var(--mono)',
        }}>
          <span>{overdue ? '⚠' : '📅'}</span>
          {formatDate(task.dueDate)}
          {overdue && ' — Overdue'}
        </div>
      )}

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: '6px', marginTop: '4px', flexWrap: 'wrap' }}>
        {flow.prev && (
          <button
            onClick={() => moveTask(flow.prev)}
            disabled={loading}
            style={{
              flex: 1, minWidth: '80px', padding: '7px 10px', fontSize: '12px',
              background: 'var(--surface2)', border: '1px solid var(--border)',
              borderRadius: '6px', color: 'var(--muted)',
              fontWeight: 500, transition: 'all 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--muted)'; e.currentTarget.style.color = 'var(--text)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--muted)' }}
          >
            {flow.prevLabel}
          </button>
        )}
        {flow.next && (
          <button
            onClick={() => moveTask(flow.next)}
            disabled={loading}
            style={{
              flex: 2, padding: '7px 10px', fontSize: '12px',
              background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
              border: 'none', borderRadius: '6px', color: '#fff',
              fontWeight: 600, transition: 'opacity 0.2s',
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? '...' : flow.nextLabel}
          </button>
        )}
      </div>
    </div>
  )
}
