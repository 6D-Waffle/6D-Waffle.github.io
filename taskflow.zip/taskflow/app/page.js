'use client'
import { useEffect, useState } from 'react'
import TaskCard from '@/components/TaskCard'
import AddTaskModal from '@/components/AddTaskModal'

const COLUMNS = [
  { id: 'todo',        label: 'To Do',       color: '#6b7a99', icon: '○' },
  { id: 'in-progress', label: 'In Progress', color: '#5b8af5', icon: '◑' },
  { id: 'done',        label: 'Done',        color: '#34d399', icon: '●' },
]

export default function Board() {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    fetch('/api/tasks')
      .then(r => r.json())
      .then(data => { setTasks(data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  function handleAdd(task) {
    setTasks(prev => [...prev, task])
  }

  function handleUpdate(updated) {
    setTasks(prev => prev.map(t => t.id === updated.id ? updated : t))
  }

  function handleDelete(id) {
    setTasks(prev => prev.filter(t => t.id !== id))
  }

  const filteredTasks = filter === 'all'
    ? tasks
    : tasks.filter(t => t.priority === filter)

  const total = tasks.length
  const done  = tasks.filter(t => t.status === 'done').length
  const pct   = total ? Math.round((done / total) * 100) : 0

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>

      {/* ── Header ── */}
      <header style={{
        padding: '20px 32px',
        borderBottom: '1px solid var(--border)',
        background: 'var(--bg2)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexWrap: 'wrap', gap: '16px',
        position: 'sticky', top: 0, zIndex: 50,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: 36, height: 36, borderRadius: '10px',
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '18px',
          }}>⚡</div>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 700, letterSpacing: '-0.02em' }}>TaskFlow</h1>
            <p style={{ fontSize: '12px', color: 'var(--muted)' }}>Kanban Board</p>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: '1 1 240px', maxWidth: '300px' }}>
          <div style={{ flex: 1, height: '6px', background: 'var(--border)', borderRadius: '3px', overflow: 'hidden' }}>
            <div style={{
              width: `${pct}%`, height: '100%',
              background: 'linear-gradient(90deg, var(--accent), var(--green))',
              borderRadius: '3px', transition: 'width 0.5s ease',
            }} />
          </div>
          <span style={{ fontSize: '13px', color: 'var(--muted)', whiteSpace: 'nowrap', fontFamily: 'var(--mono)' }}>
            {done}/{total} done
          </span>
        </div>

        {/* Filter + Add */}
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <select
            value={filter}
            onChange={e => setFilter(e.target.value)}
            style={{
              background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: '8px', padding: '8px 12px', color: 'var(--text)',
              fontSize: '13px', outline: 'none',
            }}
          >
            <option value="all">All priorities</option>
            <option value="high">🔴 High</option>
            <option value="medium">🟡 Medium</option>
            <option value="low">🟢 Low</option>
          </select>

          <button
            onClick={() => setShowModal(true)}
            style={{
              padding: '9px 18px',
              background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
              border: 'none', borderRadius: '8px',
              color: '#fff', fontWeight: 600, fontSize: '14px',
              display: 'flex', alignItems: 'center', gap: '6px',
              transition: 'opacity 0.2s',
            }}
            onMouseEnter={e => e.currentTarget.style.opacity = '0.85'}
            onMouseLeave={e => e.currentTarget.style.opacity = '1'}
          >
            + Add Task
          </button>
        </div>
      </header>

      {/* ── Board ── */}
      <main style={{
        flex: 1,
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '1px',
        background: 'var(--border)',
        overflow: 'hidden',
      }}
      className="board-grid"
      >
        {COLUMNS.map(col => {
          const colTasks = filteredTasks.filter(t => t.status === col.id)
          return (
            <div key={col.id} style={{
              background: 'var(--bg)',
              display: 'flex',
              flexDirection: 'column',
              minHeight: 'calc(100vh - 85px)',
            }}>
              {/* Column header */}
              <div style={{
                padding: '20px 20px 16px',
                borderBottom: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                position: 'sticky', top: '85px',
                background: 'var(--bg)',
                zIndex: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ color: col.color, fontSize: '16px' }}>{col.icon}</span>
                  <h2 style={{ fontSize: '14px', fontWeight: 600, letterSpacing: '0.01em' }}>{col.label}</h2>
                </div>
                <span style={{
                  background: 'var(--surface)', color: 'var(--muted)',
                  fontSize: '12px', fontWeight: 600, fontFamily: 'var(--mono)',
                  padding: '2px 8px', borderRadius: '20px',
                }}>
                  {colTasks.length}
                </span>
              </div>

              {/* Cards */}
              <div style={{
                flex: 1, padding: '16px', display: 'flex',
                flexDirection: 'column', gap: '10px', overflowY: 'auto',
              }}>
                {loading ? (
                  Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} style={{
                      height: '100px', background: 'var(--surface)',
                      borderRadius: 'var(--radius)', border: '1px solid var(--border)',
                      opacity: 0.5 + i * 0.2, animation: 'fadeIn 1s ease infinite alternate',
                    }} />
                  ))
                ) : colTasks.length === 0 ? (
                  <div style={{
                    flex: 1, display: 'flex', flexDirection: 'column',
                    alignItems: 'center', justifyContent: 'center',
                    color: 'var(--muted)', fontSize: '13px', gap: '8px',
                    paddingTop: '40px',
                  }}>
                    <div style={{ fontSize: '28px', opacity: 0.3 }}>{col.icon}</div>
                    <span>No tasks here</span>
                    {col.id === 'todo' && (
                      <button
                        onClick={() => setShowModal(true)}
                        style={{
                          marginTop: '8px', padding: '7px 16px',
                          background: 'var(--surface)', border: '1px dashed var(--border)',
                          borderRadius: '6px', color: 'var(--muted)', fontSize: '12px',
                          transition: 'all 0.2s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
                        onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--muted)' }}
                      >
                        + Add your first task
                      </button>
                    )}
                  </div>
                ) : (
                  colTasks.map(task => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onUpdate={handleUpdate}
                      onDelete={handleDelete}
                    />
                  ))
                )}
              </div>
            </div>
          )
        })}
      </main>

      {showModal && (
        <AddTaskModal onClose={() => setShowModal(false)} onAdd={handleAdd} />
      )}

      <style>{`
        @media (max-width: 900px) {
          .board-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  )
}
