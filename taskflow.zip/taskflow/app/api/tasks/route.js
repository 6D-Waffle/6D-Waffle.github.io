import { NextResponse } from 'next/server'
import { readTasks, writeTasks } from '@/lib/db'
import { v4 as uuidv4 } from 'uuid'

// GET /api/tasks — return all tasks
export async function GET() {
  try {
    const tasks = readTasks()
    return NextResponse.json(tasks)
  } catch (err) {
    return NextResponse.json({ error: 'Failed to read tasks' }, { status: 500 })
  }
}

// POST /api/tasks — create a new task
export async function POST(request) {
  try {
    const body = await request.json()
    const { title, description, priority, dueDate } = body

    if (!title || title.trim() === '') {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    const newTask = {
      id: uuidv4(),
      title: title.trim(),
      description: description?.trim() || '',
      status: 'todo',
      priority: priority || 'medium',
      dueDate: dueDate || '',
      createdAt: new Date().toISOString(),
    }

    const tasks = readTasks()
    tasks.push(newTask)
    writeTasks(tasks)

    return NextResponse.json(newTask, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to create task' }, { status: 500 })
  }
}
