import { NextResponse } from 'next/server'
import { readTasks, writeTasks } from '@/lib/db'

// PATCH /api/tasks/[id] — update a task (status, title, etc.)
export async function PATCH(request, { params }) {
  try {
    const { id } = params
    const body = await request.json()
    const tasks = readTasks()
    const index = tasks.findIndex(t => t.id === id)

    if (index === -1) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 })
    }

    // Merge only allowed fields
    const allowed = ['title', 'description', 'status', 'priority', 'dueDate']
    allowed.forEach(field => {
      if (body[field] !== undefined) tasks[index][field] = body[field]
    })

    writeTasks(tasks)
    return NextResponse.json(tasks[index])
  } catch (err) {
    return NextResponse.json({ error: 'Failed to update task' }, { status: 500 })
  }
}

// DELETE /api/tasks/[id] — remove a task
export async function DELETE(request, { params }) {
  try {
    const { id } = params
    const tasks = readTasks()
    const filtered = tasks.filter(t => t.id !== id)

    if (filtered.length === tasks.length) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 })
    }

    writeTasks(filtered)
    return NextResponse.json({ success: true })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to delete task' }, { status: 500 })
  }
}
